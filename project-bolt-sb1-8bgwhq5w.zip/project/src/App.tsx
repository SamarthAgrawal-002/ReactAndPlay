import React, { useState, useEffect, useCallback } from 'react';
import { Home, Users, Play, Trophy, Clock, Star, Heart, Zap } from 'lucide-react';

// Types
interface Player {
  id: string;
  name: string;
  score: number;
  isConnected: boolean;
}

interface Room {
  id: string;
  players: Player[];
  currentActorIndex: number;
  round: number;
  gameState: 'waiting' | 'playing' | 'acting' | 'guessing' | 'finished';
  timeLeft: number;
  currentPrompt?: string;
  category?: string;
}

interface Guess {
  playerId: string;
  playerName: string;
  text: string;
  timestamp: number;
}

// Prompts data
const PROMPTS = {
  bollywood: [
    'Sholay', 'Dilwale Dulhania Le Jayenge', 'Dangal', 'Lagaan', 'Queen', 
    'Zindagi Na Milegi Dobara', 'Taare Zameen Par', '3 Idiots', 'My Name is Khan',
    'Kuch Kuch Hota Hai', 'Kabhi Khushi Kabhie Gham', 'Mughal-E-Azam'
  ],
  hollywood: [
    'Titanic', 'Avatar', 'The Lion King', 'Frozen', 'Spider-Man',
    'Harry Potter', 'Star Wars', 'Jurassic Park', 'The Avengers',
    'Finding Nemo', 'Toy Story', 'The Matrix'
  ],
  cartoons: [
    'Tom and Jerry', 'Mickey Mouse', 'Doraemon', 'Chota Bheem',
    'Scooby-Doo', 'The Jungle Book', 'Aladdin', 'Beauty and the Beast',
    'Shrek', 'Ice Age', 'Madagascar', 'Kung Fu Panda'
  ],
  sports: [
    'Cricket', 'Football', 'Basketball', 'Tennis', 'Swimming',
    'Boxing', 'Wrestling', 'Badminton', 'Volleyball', 'Golf',
    'Hockey', 'Table Tennis'
  ],
  actions: [
    'Brushing teeth', 'Cooking food', 'Dancing', 'Singing in shower',
    'Driving a car', 'Flying a kite', 'Playing guitar', 'Reading a book',
    'Taking a selfie', 'Exercising', 'Gardening', 'Painting'
  ],
  animals: [
    'Elephant', 'Lion', 'Monkey', 'Peacock', 'Snake', 'Frog',
    'Rabbit', 'Tiger', 'Bear', 'Giraffe', 'Penguin', 'Dolphin'
  ]
};

// Components
const HomePage: React.FC<{
  onCreateRoom: (playerName: string) => void;
  onJoinRoom: (roomCode: string, playerName: string) => void;
}> = ({ onCreateRoom, onJoinRoom }) => {
  const [playerName, setPlayerName] = useState('');
  const [roomCode, setRoomCode] = useState('');
  const [isJoining, setIsJoining] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName.trim()) return;
    
    if (isJoining) {
      if (roomCode.trim()) {
        onJoinRoom(roomCode.toUpperCase(), playerName);
      }
    } else {
      onCreateRoom(playerName);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-400 to-orange-400 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="mb-4">
            <Heart className="h-16 w-16 text-white mx-auto mb-2" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">Dumb Charades</h1>
          <p className="text-white/90 text-lg">Relive childhood memories with friends & family</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-gray-700 font-medium mb-2">Your Name</label>
              <input
                type="text"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent"
                placeholder="Enter your name"
                required
              />
            </div>

            <div className="flex space-x-2">
              <button
                type="button"
                onClick={() => setIsJoining(false)}
                className={`flex-1 py-3 rounded-xl font-medium transition-all ${
                  !isJoining
                    ? 'bg-purple-100 text-purple-700 border-2 border-purple-300'
                    : 'bg-gray-100 text-gray-600 border-2 border-gray-200'
                }`}
              >
                <Play className="h-5 w-5 inline mr-2" />
                Create Room
              </button>
              <button
                type="button"
                onClick={() => setIsJoining(true)}
                className={`flex-1 py-3 rounded-xl font-medium transition-all ${
                  isJoining
                    ? 'bg-purple-100 text-purple-700 border-2 border-purple-300'
                    : 'bg-gray-100 text-gray-600 border-2 border-gray-200'
                }`}
              >
                <Users className="h-5 w-5 inline mr-2" />
                Join Room
              </button>
            </div>

            {isJoining && (
              <div>
                <label className="block text-gray-700 font-medium mb-2">Room Code</label>
                <input
                  type="text"
                  value={roomCode}
                  onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent text-center text-lg font-bold tracking-wider"
                  placeholder="ABCD12"
                  maxLength={6}
                />
              </div>
            )}

            <button
              type="submit"
              disabled={!playerName.trim() || (isJoining && !roomCode.trim())}
              className="w-full py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-bold text-lg hover:from-purple-600 hover:to-pink-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-105 active:scale-95"
            >
              {isJoining ? 'Join Game' : 'Create Room'}
            </button>
          </form>
        </div>

        <div className="text-center mt-8 text-white/80 text-sm">
          <p>🎭 Act • Guess • Laugh • Repeat 🎭</p>
        </div>
      </div>
    </div>
  );
};

const GameRoom: React.FC<{
  room: Room;
  currentPlayer: Player;
  guesses: Guess[];
  onStartGame: () => void;
  onSubmitGuess: (guess: string) => void;
  onNextRound: () => void;
  onLeaveRoom: () => void;
}> = ({ room, currentPlayer, guesses, onStartGame, onSubmitGuess, onNextRound, onLeaveRoom }) => {
  const [guess, setGuess] = useState('');
  const currentActor = room.players[room.currentActorIndex];
  const isCurrentPlayerActor = currentActor?.id === currentPlayer.id;
  const canGuess = room.gameState === 'guessing' && !isCurrentPlayerActor;

  const handleGuessSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (guess.trim() && canGuess) {
      onSubmitGuess(guess.trim());
      setGuess('');
    }
  };

  const getGameStateDisplay = () => {
    switch (room.gameState) {
      case 'waiting':
        return 'Waiting for players...';
      case 'playing':
        return 'Game Starting!';
      case 'acting':
        return isCurrentPlayerActor ? 'Your turn to act!' : `${currentActor?.name} is acting...`;
      case 'guessing':
        return isCurrentPlayerActor ? 'Keep acting!' : 'Guess the prompt!';
      case 'finished':
        return 'Game Complete!';
      default:
        return '';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Room: {room.id}</h1>
              <p className="text-gray-600">Round {room.round}</p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-purple-600">{Math.max(0, room.timeLeft)}</div>
              <div className="text-sm text-gray-500 flex items-center justify-end">
                <Clock className="h-4 w-4 mr-1" />
                seconds left
              </div>
            </div>
          </div>
          
          <div className="mt-4">
            <div className="text-lg font-medium text-gray-700 mb-2">{getGameStateDisplay()}</div>
            {room.timeLeft > 0 && room.gameState === 'guessing' && (
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-green-400 to-blue-500 h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${(room.timeLeft / 60) * 100}%` }}
                ></div>
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Game Area */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
              {room.gameState === 'waiting' && (
                <div className="text-center py-12">
                  <Users className="h-16 w-16 text-purple-400 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Waiting for More Players</h3>
                  <p className="text-gray-600 mb-6">Share the room code with your friends!</p>
                  {room.players.length >= 2 && (
                    <button
                      onClick={onStartGame}
                      className="px-8 py-3 bg-gradient-to-r from-green-400 to-blue-500 text-white rounded-xl font-bold hover:from-green-500 hover:to-blue-600 transition-all transform hover:scale-105"
                    >
                      Start Game
                    </button>
                  )}
                </div>
              )}

              {(room.gameState === 'acting' || room.gameState === 'guessing') && (
                <div className="text-center">
                  {/* Actor's Prompt (only visible to actor) */}
                  {isCurrentPlayerActor && room.currentPrompt && (
                    <div className="bg-gradient-to-r from-yellow-100 to-orange-100 border-2 border-yellow-300 rounded-xl p-6 mb-6">
                      <h3 className="text-lg font-bold text-gray-800 mb-2">Your Prompt:</h3>
                      <div className="text-3xl font-bold text-orange-600">{room.currentPrompt}</div>
                      <div className="text-sm text-gray-600 mt-2">Category: {room.category}</div>
                      <div className="text-sm text-yellow-700 mt-4">
                        🎭 Act it out without speaking! Use gestures, expressions, and movements.
                      </div>
                    </div>
                  )}

                  {/* Video Area Placeholder */}
                  <div className="bg-gradient-to-br from-gray-100 to-gray-200 rounded-xl p-12 mb-6 border-4 border-dashed border-gray-300">
                    <div className="text-center">
                      <Zap className="h-24 w-24 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl font-bold text-gray-600 mb-2">
                        {isCurrentPlayerActor ? 'You are acting!' : `${currentActor?.name} is performing`}
                      </h3>
                      <p className="text-gray-500">
                        {isCurrentPlayerActor 
                          ? 'Show your best acting skills!' 
                          : 'Watch carefully and type your guess below!'
                        }
                      </p>
                    </div>
                  </div>

                  {/* Guess Input */}
                  {canGuess && (
                    <form onSubmit={handleGuessSubmit} className="max-w-md mx-auto">
                      <div className="flex space-x-2">
                        <input
                          type="text"
                          value={guess}
                          onChange={(e) => setGuess(e.target.value)}
                          className="flex-1 px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent"
                          placeholder="Type your guess..."
                          autoComplete="off"
                        />
                        <button
                          type="submit"
                          disabled={!guess.trim()}
                          className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-bold hover:from-purple-600 hover:to-pink-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                        >
                          Guess
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {room.gameState === 'finished' && (
                <div className="text-center py-12">
                  <Trophy className="h-16 w-16 text-yellow-400 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-gray-800 mb-4">Game Complete! 🎉</h3>
                  <div className="max-w-md mx-auto">
                    {room.players
                      .sort((a, b) => b.score - a.score)
                      .slice(0, 3)
                      .map((player, index) => (
                        <div
                          key={player.id}
                          className={`flex items-center justify-between p-4 rounded-xl mb-2 ${
                            index === 0
                              ? 'bg-gradient-to-r from-yellow-100 to-yellow-200 border-2 border-yellow-400'
                              : index === 1
                              ? 'bg-gradient-to-r from-gray-100 to-gray-200 border-2 border-gray-300'
                              : 'bg-gradient-to-r from-orange-100 to-orange-200 border-2 border-orange-300'
                          }`}
                        >
                          <div className="flex items-center">
                            <div className={`text-2xl mr-3`}>
                              {index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉'}
                            </div>
                            <span className="font-bold">{player.name}</span>
                          </div>
                          <span className="text-xl font-bold">{player.score}</span>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>

            {/* Game Controls */}
            {room.gameState !== 'waiting' && room.gameState !== 'finished' && (
              <div className="bg-white rounded-2xl shadow-xl p-6">
                <div className="flex justify-between items-center">
                  <button
                    onClick={onLeaveRoom}
                    className="px-6 py-2 bg-gray-500 text-white rounded-xl font-medium hover:bg-gray-600 transition-all"
                  >
                    Leave Room
                  </button>
                  {room.timeLeft === 0 && (
                    <button
                      onClick={onNextRound}
                      className="px-6 py-2 bg-gradient-to-r from-green-400 to-blue-500 text-white rounded-xl font-bold hover:from-green-500 hover:to-blue-600 transition-all"
                    >
                      Next Round
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Players List */}
            <div className="bg-white rounded-2xl shadow-xl p-6">
              <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Players ({room.players.length})
              </h3>
              <div className="space-y-2">
                {room.players.map((player, index) => (
                  <div
                    key={player.id}
                    className={`flex items-center justify-between p-3 rounded-xl ${
                      index === room.currentActorIndex
                        ? 'bg-gradient-to-r from-purple-100 to-pink-100 border-2 border-purple-300'
                        : 'bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className={`w-3 h-3 rounded-full mr-3 ${
                        player.isConnected ? 'bg-green-400' : 'bg-gray-300'
                      }`} />
                      <span className={`font-medium ${
                        index === room.currentActorIndex ? 'text-purple-700' : 'text-gray-700'
                      }`}>
                        {player.name}
                        {player.id === currentPlayer.id && ' (You)'}
                      </span>
                      {index === room.currentActorIndex && (
                        <Star className="h-4 w-4 text-purple-500 ml-2" />
                      )}
                    </div>
                    <span className="font-bold text-gray-600">{player.score}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Live Guesses */}
            {(room.gameState === 'guessing' || room.gameState === 'acting') && (
              <div className="bg-white rounded-2xl shadow-xl p-6">
                <h3 className="text-lg font-bold text-gray-800 mb-4">Live Guesses</h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {guesses.length === 0 ? (
                    <p className="text-gray-500 text-center py-4">No guesses yet...</p>
                  ) : (
                    guesses.slice(-10).reverse().map((guess, index) => (
                      <div
                        key={`${guess.playerId}-${guess.timestamp}`}
                        className="bg-gray-50 rounded-lg p-3 border-l-4 border-purple-300"
                      >
                        <div className="text-sm font-medium text-purple-600">
                          {guess.playerName}
                        </div>
                        <div className="text-gray-700">{guess.text}</div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Main App Component
const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<'home' | 'game'>('home');
  const [room, setRoom] = useState<Room | null>(null);
  const [currentPlayer, setCurrentPlayer] = useState<Player | null>(null);
  const [guesses, setGuesses] = useState<Guess[]>([]);

  // Generate random room code
  const generateRoomCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  // Generate random prompt
  const getRandomPrompt = () => {
    const categories = Object.keys(PROMPTS) as Array<keyof typeof PROMPTS>;
    const category = categories[Math.floor(Math.random() * categories.length)];
    const prompts = PROMPTS[category];
    const prompt = prompts[Math.floor(Math.random() * prompts.length)];
    return { prompt, category };
  };

  // Create room
  const handleCreateRoom = (playerName: string) => {
    const roomId = generateRoomCode();
    const player: Player = {
      id: 'player-1',
      name: playerName,
      score: 0,
      isConnected: true,
    };

    const newRoom: Room = {
      id: roomId,
      players: [player],
      currentActorIndex: 0,
      round: 1,
      gameState: 'waiting',
      timeLeft: 0,
    };

    setRoom(newRoom);
    setCurrentPlayer(player);
    setCurrentView('game');
  };

  // Join room (simulated)
  const handleJoinRoom = (roomCode: string, playerName: string) => {
    // In a real implementation, this would connect to an existing room
    // For demo, we'll create a room with some mock players
    const player: Player = {
      id: `player-${Date.now()}`,
      name: playerName,
      score: 0,
      isConnected: true,
    };

    const mockPlayers: Player[] = [
      { id: 'player-1', name: 'Alice', score: 15, isConnected: true },
      { id: 'player-2', name: 'Bob', score: 10, isConnected: true },
      player,
    ];

    const newRoom: Room = {
      id: roomCode,
      players: mockPlayers,
      currentActorIndex: 0,
      round: 1,
      gameState: 'waiting',
      timeLeft: 0,
    };

    setRoom(newRoom);
    setCurrentPlayer(player);
    setCurrentView('game');
  };

  // Start game
  const handleStartGame = useCallback(() => {
    if (!room) return;

    const { prompt, category } = getRandomPrompt();
    
    setRoom(prev => prev ? {
      ...prev,
      gameState: 'acting',
      timeLeft: 60,
      currentPrompt: prompt,
      category,
    } : null);

    // Start timer
    const timer = setInterval(() => {
      setRoom(prev => {
        if (!prev || prev.timeLeft <= 0) {
          clearInterval(timer);
          return prev ? { ...prev, gameState: 'guessing', timeLeft: 0 } : null;
        }
        return { ...prev, timeLeft: prev.timeLeft - 1 };
      });
    }, 1000);

    // Auto-transition to guessing after 5 seconds
    setTimeout(() => {
      setRoom(prev => prev ? { ...prev, gameState: 'guessing' } : null);
    }, 5000);
  }, [room]);

  // Submit guess
  const handleSubmitGuess = useCallback((guessText: string) => {
    if (!room || !currentPlayer) return;

    const newGuess: Guess = {
      playerId: currentPlayer.id,
      playerName: currentPlayer.name,
      text: guessText,
      timestamp: Date.now(),
    };

    setGuesses(prev => [...prev, newGuess]);

    // Check if guess is correct (simplified logic)
    const isCorrect = room.currentPrompt && 
      guessText.toLowerCase().includes(room.currentPrompt.toLowerCase()) ||
      room.currentPrompt?.toLowerCase().includes(guessText.toLowerCase());

    if (isCorrect && room.currentPrompt) {
      // Award points
      const updatedPlayers = room.players.map(p => {
        if (p.id === currentPlayer.id) return { ...p, score: p.score + 10 }; // Guesser gets 10 points
        if (p.id === room.players[room.currentActorIndex].id) return { ...p, score: p.score + 5 }; // Actor gets 5 points
        return p;
      });

      setRoom(prev => prev ? {
        ...prev,
        players: updatedPlayers,
        timeLeft: 0,
      } : null);

      // Show success feedback
      setTimeout(() => {
        handleNextRound();
      }, 2000);
    }
  }, [room, currentPlayer]);

  // Next round
  const handleNextRound = useCallback(() => {
    if (!room) return;

    const nextActorIndex = (room.currentActorIndex + 1) % room.players.length;
    const isGameFinished = room.round >= room.players.length * 2; // 2 rounds per player

    if (isGameFinished) {
      setRoom(prev => prev ? { ...prev, gameState: 'finished' } : null);
      return;
    }

    const { prompt, category } = getRandomPrompt();
    
    setRoom(prev => prev ? {
      ...prev,
      currentActorIndex: nextActorIndex,
      round: prev.round + 1,
      gameState: 'acting',
      timeLeft: 60,
      currentPrompt: prompt,
      category,
    } : null);

    setGuesses([]);

    // Auto-transition to guessing after 5 seconds
    setTimeout(() => {
      setRoom(prev => prev ? { ...prev, gameState: 'guessing' } : null);
    }, 5000);

    // Start timer
    const timer = setInterval(() => {
      setRoom(prev => {
        if (!prev || prev.timeLeft <= 0) {
          clearInterval(timer);
          return prev;
        }
        return { ...prev, timeLeft: prev.timeLeft - 1 };
      });
    }, 1000);
  }, [room]);

  // Leave room
  const handleLeaveRoom = () => {
    setRoom(null);
    setCurrentPlayer(null);
    setGuesses([]);
    setCurrentView('home');
  };

  return (
    <div className="App">
      {currentView === 'home' && (
        <HomePage
          onCreateRoom={handleCreateRoom}
          onJoinRoom={handleJoinRoom}
        />
      )}
      
      {currentView === 'game' && room && currentPlayer && (
        <GameRoom
          room={room}
          currentPlayer={currentPlayer}
          guesses={guesses}
          onStartGame={handleStartGame}
          onSubmitGuess={handleSubmitGuess}
          onNextRound={handleNextRound}
          onLeaveRoom={handleLeaveRoom}
        />
      )}
    </div>
  );
};

export default App;